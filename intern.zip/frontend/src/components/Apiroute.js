const api = "https://internship-1-backend-17me.onrender.com"
export default api;